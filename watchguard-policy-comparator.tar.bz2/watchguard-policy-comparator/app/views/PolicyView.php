<?php
class PolicyView {
    public function render($comparisonResults, $file1, $file2) {
        $this->renderHeader($comparisonResults['type']);
        $this->renderStatistics($comparisonResults['statistics'], $file1, $file2, $comparisonResults['differences']);
        $this->renderDifferences($comparisonResults['differences'], $comparisonResults['type']);
        $this->renderFooter();
    }

    private function renderHeader($type) {
        $title = $type === 'policy' ? 'WatchGuard Policy Comparator' : 'WatchGuard System Config Comparator';
        $subtitle = $type === 'policy' ? 'Vergleich von Firebox Policy-Dateien' : 'Vergleich von Firebox System-Konfigurationsdateien';

        echo '<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . htmlspecialchars($title) . '</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.6); }
        .modal-content { background-color: #fefefe; margin: 5% auto; padding: 25px; border-radius: 8px; width: 80%; max-width: 1200px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); max-height: 85vh; overflow-y: auto; }
        .close { color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer; }
        .close:hover { color: #000; }
        .category-detail-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .category-detail-table th, .category-detail-table td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        .category-detail-table th { background-color: #2c3e50; color: white; position: sticky; top: 0; }
        .category-detail-table tr:nth-child(even) { background-color: #f2f2f2; }
        .category-detail-table tr:hover { background-color: #e9e9e9; }
        .file1-value { color: #3498db; font-weight: bold; }
        .file2-value { color: #e74c3c; font-weight: bold; }
        .stat-card { cursor: pointer; transition: all 0.3s ease; }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 6px 12px rgba(0,0,0,0.15); }
        .stat-hint { font-size: 0.8em; opacity: 0.7; margin-top: 5px; text-align: center; font-style: italic; }
        .policy-name { font-weight: bold; color: #2c3e50; font-size: 1.1em; display: block; margin-bottom: 5px; }
        .diff-detail { margin-top: 8px; padding: 10px; background: rgba(255, 255, 255, 0.7); border-radius: 4px; border-left: 4px solid #ddd; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>' . htmlspecialchars($title) . '</h1>
            <p class="subtitle">' . htmlspecialchars($subtitle) . '</p>
        </header>
        <main>';
    }

    private function renderStatistics($statistics, $file1, $file2, $differences) {
        echo '<section class="statistics-section">
            <h2>Statistische Übersicht</h2>
            <div class="file-info">
                <div class="file-card">
                    <h3>Datei 1: ' . htmlspecialchars(basename($file1)) . '</h3>
                </div>
                <div class="file-card">
                    <h3>Datei 2: ' . htmlspecialchars(basename($file2)) . '</h3>
                </div>
            </div>
            <div class="stats-grid">';

        foreach ($statistics as $key => $stats) {
            $diff = $stats['difference'];
            $diffClass = $diff > 0 ? 'positive' : ($diff < 0 ? 'negative' : 'neutral');
            $label = $this->getCategoryLabel($key);

            // Daten für Modal vorbereiten - nur gültige, nicht-leere Einträge
            $allData = $this->prepareModalData($key, $differences[$key]['data'] ?? []);

            $jsonData = base64_encode(json_encode($allData));

            echo '<div class="stat-card"
                 data-category="' . htmlspecialchars($key) . '"
                 data-label="' . htmlspecialchars($label) . '"
                 data-data="' . htmlspecialchars($jsonData) . '"
                 onclick="showCategoryDetails(this)">

                <div class="stat-label">' . htmlspecialchars($label) . '</div>
                <div class="stat-values">
                    <span class="value file1">' . $stats['file1'] . '</span>
                    <span class="separator">→</span>
                    <span class="value file2">' . $stats['file2'] . '</span>
                </div>
                <div class="stat-diff ' . $diffClass . '">' . ($diff >= 0 ? '+' : '') . $diff . '</div>
                <div class="stat-hint">Klicken für alle Einträge</div>
            </div>';
        }

        echo '</div></section>

        <div id="categoryModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <div id="modalContent"></div>
            </div>
        </div>';
    }

    /**
     * Bereitet Daten für das Modal vor:
     * - Filtert leere Einträge
     * - Extrahiert Policy-Namen
     * - Sortiert alphabetisch
     */
    private function prepareModalData($category, $diffData) {
        $file1Data = [];
        $file2Data = [];

        // Identische Einträge
        foreach ($diffData['identical'] ?? [] as $key => $value) {
            if ($this->isValidEntry($value, $category)) {
                $displayKey = $this->getDisplayName($category, $value, $key);
                $file1Data[$displayKey] = $value;
                $file2Data[$displayKey] = $value;
            }
        }

        // Nur in Datei 1
        foreach ($diffData['only_in_file1'] ?? [] as $key => $value) {
            if ($this->isValidEntry($value, $category)) {
                $displayKey = $this->getDisplayName($category, $value, $key);
                $file1Data[$displayKey] = $value;
            }
        }

        // Nur in Datei 2
        foreach ($diffData['only_in_file2'] ?? [] as $key => $value) {
            if ($this->isValidEntry($value, $category)) {
                $displayKey = $this->getDisplayName($category, $value, $key);
                $file2Data[$displayKey] = $value;
            }
        }

        // Unterschiedliche Einträge
        foreach ($diffData['different'] ?? [] as $key => $values) {
            if ($this->isValidEntry($values['file1'], $category) || $this->isValidEntry($values['file2'], $category)) {
                $displayKey = $this->getDisplayName($category, $values['file1'], $key);
                $file1Data[$displayKey] = $values['file1'];
                $file2Data[$displayKey] = $values['file2'];
            }
        }

        // Alphabetisch sortieren
        ksort($file1Data);
        ksort($file2Data);

        return [
            'file1' => $file1Data,
            'file2' => $file2Data
        ];
    }

    /**
     * Prüft, ob ein Eintrag gültig ist (nicht leer)
     */
    private function isValidEntry($entry, $category = '') {
        if ($entry === null || $entry === '') {
            return false;
        }

        if (is_array($entry)) {
            if (empty($entry)) {
                return false;
            }

            // Spezielle Prüfung für Policies
            if ($category === 'policies') {
                // Eine Policy muss mindestens 'name' oder 'action' oder 'from' haben
                $requiredFields = ['name', 'Name', 'action', 'from', 'to'];
                foreach ($requiredFields as $field) {
                    if (isset($entry[$field]) && $entry[$field] !== null && $entry[$field] !== '') {
                        return true;
                    }
                }
                return false;
            }

            // Für andere Kategorien: Mindestens ein nicht-leeres Feld
            foreach ($entry as $value) {
                if ($value !== null && $value !== '') {
                    return true;
                }
            }
            return false;
        }

        return true;
    }

    /**
     * Extrahiert den Anzeigenamen für eine Kategorie
     */
    private function getDisplayName($category, $value, $key) {
        // Für Policies: Verwende das 'name'-Feld wenn vorhanden
        if ($category === 'policies') {
            if (is_array($value)) {
                if (isset($value['name']) && $value['name'] !== '') return $value['name'];
                if (isset($value['Name']) && $value['Name'] !== '') return $value['Name'];
            }
            if (is_string($key) && $key !== '') {
                return $key;
            }
        }

        // Für andere Kategorien
        if (is_array($value)) {
            if (isset($value['name']) && $value['name'] !== '') return $value['name'];
            if (isset($value['Name']) && $value['Name'] !== '') return $value['Name'];
            if (isset($value['id']) && $value['id'] !== '') return $value['id'];
        }

        return $key;
    }

    private function renderDifferences($differences, $type) {
        echo '<section class="differences-section">
            <h2>Detaillierte Unterschiede</h2>';

        foreach ($differences as $category => $data) {
            $diffData = $data['data'];
            if (empty($diffData['only_in_file1']) &&
                empty($diffData['only_in_file2']) &&
                empty($diffData['different'])) {
                continue;
            }

            echo '<div class="category-section">
                <h3>' . htmlspecialchars($data['label']) . '</h3>';

            if ($category === 'policies') {
                $this->renderPoliciesDifferences($diffData);
            } else {
                $this->renderStandardDifferences($diffData);
            }

            echo '</div>';
        }

        echo '</section>';
    }

    private function renderPoliciesDifferences($diffData) {
        if (!empty($diffData['only_in_file1'])) {
            echo '<div class="diff-group only-file1">
                <h4>Nur in Datei 1 (' . count($diffData['only_in_file1']) . ')</h4>
                <ul>';
            foreach ($diffData['only_in_file1'] as $name => $value) {
                if ($this->isValidEntry($value, 'policies')) {
                    $displayName = $this->getDisplayName('policies', $value, $name);
                    echo '<li><span class="policy-name">' . htmlspecialchars($displayName) . '</span>: ' . htmlspecialchars(json_encode($value)) . '</li>';
                }
            }
            echo '</ul></div>';
        }

        if (!empty($diffData['only_in_file2'])) {
            echo '<div class="diff-group only-file2">
                <h4>Nur in Datei 2 (' . count($diffData['only_in_file2']) . ')</h4>
                <ul>';
            foreach ($diffData['only_in_file2'] as $name => $value) {
                if ($this->isValidEntry($value, 'policies')) {
                    $displayName = $this->getDisplayName('policies', $value, $name);
                    echo '<li><span class="policy-name">' . htmlspecialchars($displayName) . '</span>: ' . htmlspecialchars(json_encode($value)) . '</li>';
                }
            }
            echo '</ul></div>';
        }

        if (!empty($diffData['different'])) {
            echo '<div class="diff-group different">
                <h4>Unterschiedlich (' . count($diffData['different']) . ')</h4>
                <ul>';
            foreach ($diffData['different'] as $name => $values) {
                if ($this->isValidEntry($values['file1'], 'policies') || $this->isValidEntry($values['file2'], 'policies')) {
                    $displayName = $this->getDisplayName('policies', $values['file1'], $name);
                    echo '<li>
                        <span class="policy-name">' . htmlspecialchars($displayName) . '</span>
                        <div class="diff-detail">
                            <span class="file1">Datei 1: ' . htmlspecialchars(json_encode($values['file1'])) . '</span><br>
                            <span class="file2">Datei 2: ' . htmlspecialchars(json_encode($values['file2'])) . '</span>
                        </div>
                    </li>';
                }
            }
            echo '</ul></div>';
        }
    }

    private function renderStandardDifferences($diffData) {
        if (!empty($diffData['only_in_file1'])) {
            echo '<div class="diff-group only-file1">
                <h4>Nur in Datei 1 (' . count($diffData['only_in_file1']) . ')</h4>
                <ul>';
            foreach ($diffData['only_in_file1'] as $key => $value) {
                if ($this->isValidEntry($value)) {
                    $displayKey = $this->getDisplayName('', $value, $key);
                    echo '<li><strong>' . htmlspecialchars($displayKey) . '</strong>: ' . htmlspecialchars(json_encode($value)) . '</li>';
                }
            }
            echo '</ul></div>';
        }

        if (!empty($diffData['only_in_file2'])) {
            echo '<div class="diff-group only-file2">
                <h4>Nur in Datei 2 (' . count($diffData['only_in_file2']) . ')</h4>
                <ul>';
            foreach ($diffData['only_in_file2'] as $key => $value) {
                if ($this->isValidEntry($value)) {
                    $displayKey = $this->getDisplayName('', $value, $key);
                    echo '<li><strong>' . htmlspecialchars($displayKey) . '</strong>: ' . htmlspecialchars(json_encode($value)) . '</li>';
                }
            }
            echo '</ul></div>';
        }

        if (!empty($diffData['different'])) {
            echo '<div class="diff-group different">
                <h4>Unterschiedlich (' . count($diffData['different']) . ')</h4>
                <ul>';
            foreach ($diffData['different'] as $key => $values) {
                if ($this->isValidEntry($values['file1']) || $this->isValidEntry($values['file2'])) {
                    $displayKey = $this->getDisplayName('', $values['file1'], $key);
                    echo '<li>
                        <strong>' . htmlspecialchars($displayKey) . '</strong>
                        <div class="diff-detail">
                            <span class="file1">Datei 1: ' . htmlspecialchars(json_encode($values['file1'])) . '</span><br>
                            <span class="file2">Datei 2: ' . htmlspecialchars(json_encode($values['file2'])) . '</span>
                        </div>
                    </li>';
                }
            }
            echo '</ul></div>';
        }
    }

    private function getCategoryLabel($key) {
        $labels = [
            'aliases' => 'Aliase',
            'policies' => 'Policies',
            'services' => 'Services',
            'interfaces' => 'Interfaces',
            'users' => 'Benutzer',
            'groups' => 'Gruppen',
            'accounts' => 'Benutzerkonten',
            'routes' => 'Routing-Einträge',
            'blockedIps' => 'Blockierte IPs',
            'exceptionIps' => 'IP-Ausnahmen',
            'dnsServers' => 'DNS-Server',
            'ntpServers' => 'NTP-Server',
            'ldapConfig' => 'LDAP-Konfiguration',
            'snmpConfig' => 'SNMP-Konfiguration',
            'dynamicRouting' => 'Dynamic Routing'
        ];
        return $labels[$key] ?? $key;
    }

    private function renderFooter() {
        echo '</main>
        <footer>
            <p>WatchGuard Comparator - MVC Application</p>
        </footer>

        <script>
        function showCategoryDetails(element) {
            try {
                var category = element.getAttribute("data-category");
                var label = element.getAttribute("data-label");
                var encodedData = element.getAttribute("data-data");
                var allData = JSON.parse(atob(encodedData));

                var html = "<h2>Alle Einträge für: " + escapeHtml(label) + "</h2>";
                html += "<div style=\"margin: 20px 0;\">";

                // Datei 1
                html += "<h3>Datei 1 (" + Object.keys(allData.file1).length + " Einträge)</h3>";
                html += "<table class=\"category-detail-table\"><thead><tr><th>Name</th><th>Details</th></tr></thead><tbody>";

                // Alphabetisch sortierte Schlüssel
                var sortedKeys = Object.keys(allData.file1).sort();
                for (var i = 0; i < sortedKeys.length; i++) {
                    var key = sortedKeys[i];
                    var value = allData.file1[key];
                    var displayName = key;

                    // Für Policies: Versuche, den Namen aus dem Objekt zu extrahieren
                    if (category === "policies" && typeof value === "object" && value !== null) {
                        if (value.hasOwnProperty("name") && value.name !== "") {
                            displayName = value.name;
                        } else if (value.hasOwnProperty("Name") && value.Name !== "") {
                            displayName = value.Name;
                        }
                    }

                    html += "<tr><td><strong>" + escapeHtml(displayName) + "</strong></td>";
                    html += "<td class=\"file1-value\">" + escapeHtml(JSON.stringify(value)) + "</td></tr>";
                }

                html += "</tbody></table>";

                // Datei 2
                html += "<h3 style=\"margin-top: 30px;\">Datei 2 (" + Object.keys(allData.file2).length + " Einträge)</h3>";
                html += "<table class=\"category-detail-table\"><thead><tr><th>Name</th><th>Details</th></tr></thead><tbody>";

                // Alphabetisch sortierte Schlüssel
                var sortedKeys2 = Object.keys(allData.file2).sort();
                for (var i = 0; i < sortedKeys2.length; i++) {
                    var key = sortedKeys2[i];
                    var value = allData.file2[key];
                    var displayName = key;

                    // Für Policies: Versuche, den Namen aus dem Objekt zu extrahieren
                    if (category === "policies" && typeof value === "object" && value !== null) {
                        if (value.hasOwnProperty("name") && value.name !== "") {
                            displayName = value.name;
                        } else if (value.hasOwnProperty("Name") && value.Name !== "") {
                            displayName = value.Name;
                        }
                    }

                    html += "<tr><td><strong>" + escapeHtml(displayName) + "</strong></td>";
                    html += "<td class=\"file2-value\">" + escapeHtml(JSON.stringify(value)) + "</td></tr>";
                }

                html += "</tbody></table></div>";
                document.getElementById("modalContent").innerHTML = html;
                document.getElementById("categoryModal").style.display = "block";
            } catch (e) {
                alert("Fehler beim Anzeigen der Details: " + e.message);
                console.error("Fehler:", e);
            }
        }

        function closeModal() {
            document.getElementById("categoryModal").style.display = "none";
        }

        window.onclick = function(event) {
            var modal = document.getElementById("categoryModal");
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        function escapeHtml(text) {
            if (text === null || text === undefined) return "";
            var div = document.createElement("div");
            div.textContent = text;
            return div.innerHTML;
        }
        </script>
    </div>
</body>
</html>';
    }
}