<?php
class ErrorView {
    public function render($msg, $f1=null, $f2=null) {
        echo '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fehler - WatchGuard Policy Comparator</title><link rel="stylesheet" href="css/style.css"></head><body>
<div class="container"><header><h1>Fehler beim Vergleich</h1></header>
<main class="error-main"><div class="error-card"><h2>Es ist ein Fehler aufgetreten:</h2>
<p class="error-message">'.htmlspecialchars($msg).'</p><div class="error-details">';
        if ($f1) echo '<p>Datei 1: '.htmlspecialchars(basename($f1)).'</p>';
        if ($f2) echo '<p>Datei 2: '.htmlspecialchars(basename($f2)).'</p>';
        echo '</div><a href="index.php" class="btn-primary">Zurück zum Upload</a></div></main>
<footer><p>WatchGuard Policy Comparator - MVC Application</p></footer></div></body></html>';
    }
}
