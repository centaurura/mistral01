<?php
class UploadView {
    public function render($error = null) {
        echo '<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WatchGuard Comparator - Upload</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>WatchGuard Comparator</h1>
            <p class="subtitle">Vergleich von Firebox Dateien (Policy oder System-Konfiguration)</p>
        </header>
        <main class="upload-main">';

        if ($error) {
            echo '<div class="error-message">' . htmlspecialchars($error) . '</div>';
        }

        echo '<form action="index.php" method="post" enctype="multipart/form-data" class="upload-form">
            <div class="form-group">
                <label for="file1">Datei 1 (Referenz):</label>
                <input type="file" id="file1" name="file1" accept=".xml" required>
                <small>Unterstützt: Policy-Dateien (<FireboxPolicy>) und System-Konfigurationen (&lt;profile&gt;)</small>
            </div>
            <div class="form-group">
                <label for="file2">Datei 2 (Vergleich):</label>
                <input type="file" id="file2" name="file2" accept=".xml" required>
                <small>Beide Dateien müssen vom gleichen Typ sein!</small>
            </div>
            <div class="form-actions">
                <button type="submit" name="compare" class="btn-primary">Vergleichen</button>
            </div>
        </form>
        <div class="instructions">
            <h3>Anleitung:</h3>
            <ol>
                <li><strong>Policy-Dateien</strong> enthalten: Aliases, Policies, Services, Interfaces, Users, Groups</li>
                <li><strong>System-Konfigurationen</strong> enthalten: Accounts, Routes, Blocked IPs, DNS/NTP-Server, etc.</li>
                <li>Laden Sie zwei Dateien <strong>vom gleichen Typ</strong> hoch</li>
                <li>Klicken Sie auf "Vergleichen"</li>
                <li>Sie erhalten eine statistische Übersicht und detaillierte Unterschiede</li>
            </ol>
            <p><strong>Wichtig:</strong> Vergleichen Sie nur Dateien vom gleichen Typ (Policy mit Policy, System mit System)!</p>
        </div>
        </main>
        <footer>
            <p>WatchGuard Comparator - MVC Application</p>
        </footer>
    </div>
</body>
</html>';
    }
}