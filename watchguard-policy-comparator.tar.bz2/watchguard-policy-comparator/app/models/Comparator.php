<?php
class Comparator {
    // ... (vorheriger Code bleibt gleich)

    private function compareItems($items1, $items2) {
        $onlyIn1 = [];
        $onlyIn2 = [];
        $different = [];
        $identical = [];

        foreach ($items1 as $key => $value) {
            // Nur nicht-leere Einträge verarbeiten
            if ($this->isValidEntry($value)) {
                if (!array_key_exists($key, $items2)) {
                    $onlyIn1[$key] = $value;
                } elseif (serialize($value) !== serialize($items2[$key])) {
                    $different[$key] = [
                        'file1' => $value,
                        'file2' => $items2[$key]
                    ];
                } else {
                    $identical[$key] = $value;
                }
            }
        }

        foreach ($items2 as $key => $value) {
            // Nur nicht-leere Einträge verarbeiten
            if ($this->isValidEntry($value)) {
                if (!array_key_exists($key, $items1)) {
                    $onlyIn2[$key] = $value;
                }
            }
        }

        return [
            'only_in_file1' => $onlyIn1,
            'only_in_file2' => $onlyIn2,
            'different' => $different,
            'identical' => $identical
        ];
    }

    /**
     * Prüft, ob ein Eintrag gültig ist (nicht leer)
     */
    private function isValidEntry($entry) {
        if ($entry === null || $entry === '') {
            return false;
        }
        if (is_array($entry)) {
            if (empty($entry)) {
                return false;
            }
            // Prüfe, ob alle Werte leer sind
            foreach ($entry as $value) {
                if ($value !== null && $value !== '') {
                    return true;
                }
            }
            return false;
        }
        return true;
    }

    // ... (Rest der Comparator.php bleibt gleich)
}