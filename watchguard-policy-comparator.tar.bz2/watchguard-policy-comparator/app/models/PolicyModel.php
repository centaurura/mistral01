<?php
class PolicyModel {
    private $filePath;
    private $xml;
    private $type; // 'policy' oder 'system'
    private $data = [];

    public function __construct($filePath) {
        $this->filePath = $filePath;
    }

    /**
     * Lädt und parst die XML-Datei
     */
    public function loadXml() {
        if (!file_exists($this->filePath)) {
            throw new Exception("Datei nicht gefunden: " . $this->filePath);
        }

        libxml_use_internal_errors(true);
        $content = file_get_contents($this->filePath);
        $this->xml = simplexml_load_string($content, null, LIBXML_NOCDATA | LIBXML_NOBLANKS);
        libxml_use_internal_errors(false);

        if ($this->xml === false) {
            throw new Exception("Ungültiges XML: " . $this->filePath);
        }

        $this->detectType();
        $this->parseAccordingToType();
    }

    /**
     * Erkennt den Dateityp (policy oder system)
     */
    private function detectType() {
        $rootName = $this->xml->getName();

        // 1. Prüfe Root-Element
        if ($rootName === 'profile') {
            $this->type = 'system';
            return;
        }

        if ($rootName === 'FireboxPolicy' || $rootName === 'policy') {
            $this->type = 'policy';
            return;
        }

        // 2. Prüfe typische Child-Elements für Policy-Dateien
        $policyIndicators = ['Aliases', 'Policies', 'Services', 'Interfaces', 'Users', 'Groups'];
        foreach ($policyIndicators as $indicator) {
            if (isset($this->xml->$indicator)) {
                $this->type = 'policy';
                return;
            }
        }

        // 3. Prüfe typische Child-Elements für System-Konfigurationen
        $systemIndicators = ['account-list', 'system-parameters', 'blocked-ip-list', 'route'];
        foreach ($systemIndicators as $indicator) {
            if (isset($this->xml->$indicator)) {
                $this->type = 'system';
                return;
            }
        }

        // 4. Rekursive Suche in allen Kindern
        if ($this->hasPolicyElements($this->xml)) {
            $this->type = 'policy';
        } elseif ($this->hasSystemElements($this->xml)) {
            $this->type = 'system';
        } else {
            throw new Exception("Unbekannter Dateityp. Die XML-Datei enthält weder Policy- noch System-Konfigurationselemente.");
        }
    }

    /**
     * Prüft auf Policy-Elemente
     */
    private function hasPolicyElements($node) {
        $policyTags = ['Alias', 'Policy', 'Service', 'Interface', 'User', 'Group'];
        foreach ($policyTags as $tag) {
            if (isset($node->$tag)) {
                return true;
            }
            foreach ($node->children() as $child) {
                if ($this->hasPolicyElements($child)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Prüft auf System-Elemente
     */
    private function hasSystemElements($node) {
        $systemTags = ['account-list', 'system-parameters', 'blocked-ip-list', 'route', 'dns-server-list'];
        foreach ($systemTags as $tag) {
            if (isset($node->$tag)) {
                return true;
            }
            foreach ($node->children() as $child) {
                if ($this->hasSystemElements($child)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Parst die Datei je nach Typ
     */
    private function parseAccordingToType() {
        if ($this->type === 'policy') {
            $this->parsePolicyFile();
        } elseif ($this->type === 'system') {
            $this->parseSystemConfig();
        } else {
            throw new Exception("Unbekannter Dateityp: {$this->type}");
        }
    }

    /**
     * Parst Policy-Dateien
     */
    private function parsePolicyFile() {
        $this->data = [
            'aliases' => $this->findNodesWithTag($this->xml, ['Alias', 'Host', 'Network', 'FQDN', 'IPAddress']),
            'policies' => $this->findNodesWithTag($this->xml, ['Policy', 'FirewallPolicy', 'Rule']),
            'services' => $this->findNodesWithTag($this->xml, ['Service', 'ServiceGroup', 'Port']),
            'interfaces' => $this->findNodesWithTag($this->xml, ['Interface', 'NetworkInterface']),
            'users' => $this->findNodesWithTag($this->xml, ['User', 'AuthUser']),
            'groups' => $this->findNodesWithTag($this->xml, ['Group', 'UserGroup', 'AuthGroup'])
        ];
    }

    /**
     * Parst System-Konfigurationen
     */
    private function parseSystemConfig() {
        $this->data = [
            'accounts' => $this->parseAccounts(),
            'routes' => $this->parseRoutes(),
            'blockedIps' => $this->parseBlockedIps(),
            'exceptionIps' => $this->parseExceptionIps(),
            'dnsServers' => $this->parseDnsServers(),
            'ntpServers' => $this->parseNtpServers(),
            'policies' => $this->parseSystemPolicies(),
            'ldapConfig' => $this->parseLdapConfig(),
            'snmpConfig' => $this->parseSnmpConfig(),
            'dynamicRouting' => $this->parseDynamicRouting()
        ];
    }

    /**
     * Parst System-Policies
     */
    private function parseSystemPolicies() {
        $policies = [];

        // 1. Suche nach verschiedenen Policy-Tags
        $policyTags = ['policy', 'Policy', 'FirewallPolicy', 'Rule', 'PacketFilter', 'policy-rule'];

        foreach ($policyTags as $tag) {
            if (isset($this->xml->$tag)) {
                foreach ($this->xml->$tag as $policy) {
                    $policyData = $this->extractPolicyData($policy);
                    if ($this->isValidPolicy($policyData)) {
                        $name = (string)($policy['name'] ?? $policy['Name'] ?? $policy['id'] ?? count($policies));
                        $policies[$name] = $policyData;
                    }
                }
                if (!empty($policies)) {
                    return $policies;
                }
            }
        }

        // 2. Rekursive Suche in allen Kindern
        $allPolicies = $this->findNodesWithTag($this->xml, $policyTags);

        // Filtere leere Policies
        foreach ($allPolicies as $name => $policyData) {
            if (!$this->isValidPolicy($policyData)) {
                unset($allPolicies[$name]);
            }
        }

        return $allPolicies;
    }

    /**
     * Prüft, ob eine Policy gültig ist (nicht leer)
     */
    private function isValidPolicy($policy) {
        if (!is_array($policy) || empty($policy)) {
            return false;
        }

        // Prüfe, ob mindestens ein Feld mit einem nicht-leeren Wert existiert
        $requiredFields = ['name', 'Name', 'action', 'from', 'to'];
        foreach ($requiredFields as $field) {
            if (isset($policy[$field]) && $policy[$field] !== null && $policy[$field] !== '') {
                return true;
            }
        }

        return false;
    }

    /**
     * Extrahiert Policy-Daten
     */
    private function extractPolicyData($policy) {
        $data = [];

        // Standard-Attribute
        $standardAttrs = ['name', 'from', 'to', 'service', 'action', 'enabled', 'id', 'description'];
        foreach ($standardAttrs as $attr) {
            if (isset($policy[$attr]) && (string)$policy[$attr] !== '') {
                $data[$attr] = (string)$policy[$attr];
            }
        }

        // Child-Elements
        foreach ($policy->children() as $key => $value) {
            $strValue = (string)$value;
            if ($strValue !== '') {
                $data[$key] = $strValue;
            }
        }

        // Spezielle WatchGuard-Attribute
        if (isset($policy->{'from-zone'}) && (string)$policy->{'from-zone'} !== '') {
            $data['from'] = (string)$policy->{'from-zone'};
        }
        if (isset($policy->{'to-zone'}) && (string)$policy->{'to-zone'} !== '') {
            $data['to'] = (string)$policy->{'to-zone'};
        }
        if (isset($policy->{'service-list'})) {
            $serviceList = $this->parseServiceList($policy->{'service-list'});
            if ($serviceList !== '') {
                $data['service'] = $serviceList;
            }
        }

        return $data;
    }

    /**
     * Parst Service-Listen
     */
    private function parseServiceList($serviceList) {
        $services = [];
        if (isset($serviceList->service)) {
            foreach ($serviceList->service as $service) {
                $services[] = (string)$service;
            }
        } elseif (isset($serviceList->{'service-name'})) {
            foreach ($serviceList->{'service-name'} as $service) {
                $services[] = (string)$service;
            }
        }
        return implode(', ', $services);
    }

    /**
     * Parst Accounts
     */
    private function parseAccounts() {
        $accounts = [];
        if (isset($this->xml->{'account-list'})) {
            foreach ($this->xml->{'account-list'}->account as $account) {
                $id = (string)$account->id;
                if ($id !== '') {
                    $accounts[$id] = [
                        'password' => (string)$account->password,
                        'description' => (string)$account->description,
                        'property' => (string)$account->property,
                        'idle_timeout' => (string)$account->{'idle-timeout'},
                        'session_timeout' => (string)$account->{'session-timeout'},
                        'roles' => $this->parseRoles($account->{'role-list'})
                    ];
                }
            }
        }
        return $accounts;
    }

    /**
     * Parst Routen
     */
    private function parseRoutes() {
        $routes = [];
        if (isset($this->xml->{'system-parameters'}->route)) {
            foreach ($this->xml->{'system-parameters'}->route->{'route-entry'} as $route) {
                $dest = (string)$route->{'dest-address'};
                $gateway = (string)$route->{'gateway-ip'};
                if ($dest !== '' && $gateway !== '') {
                    $key = $dest . '|' . $gateway;
                    $routes[$key] = [
                        'dest_address' => $dest,
                        'mask' => (string)$route->mask,
                        'gateway_ip' => $gateway,
                        'port_type' => (string)$route->{'port-type'},
                        'distance' => (string)$route->distance,
                        'metric' => (string)$route->metric
                    ];
                }
            }
        }
        return $routes;
    }

    /**
     * Parst blockierte IPs
     */
    private function parseBlockedIps() {
        $ips = [];
        if (isset($this->xml->{'blocked-ip-list'})) {
            foreach ($this->xml->{'blocked-ip-list'}->{'blocked-ip'} as $ip) {
                $hostIp = (string)$ip->{'host-ip-addr'};
                $ipType = (string)$ip->{'ip-type'};
                if ($hostIp !== '' && $ipType !== '') {
                    $key = $hostIp . '|' . $ipType;
                    $ips[$key] = [
                        'ip_type' => $ipType,
                        'host_ip' => $hostIp,
                        'description' => (string)$ip->description
                    ];
                }
            }
        }
        return $ips;
    }

    /**
     * Parst IP-Ausnahmen
     */
    private function parseExceptionIps() {
        $ips = [];
        if (isset($this->xml->{'blocked-ip-exception-list'})) {
            foreach ($this->xml->{'blocked-ip-exception-list'}->{'exception-ip'} as $ip) {
                $ipType = (string)$ip->{'ip-type'};
                $ipAddress = (string)($ip->{'ip-network-addr'} ?? $ip->{'host-ip-addr'});
                if ($ipAddress !== '' && $ipType !== '') {
                    $key = $ipAddress . '|' . $ipType;
                    $ips[$key] = [
                        'ip_type' => $ipType,
                        'ip_address' => $ipAddress,
                        'ip_mask' => (string)($ip->{'ip-mask'} ?? ''),
                        'start_ip' => (string)($ip->{'start-ip-addr'} ?? ''),
                        'end_ip' => (string)($ip->{'end-ip-addr'} ?? ''),
                        'description' => (string)$ip->description
                    ];
                }
            }
        }
        return $ips;
    }

    /**
     * Parst DNS-Server
     */
    private function parseDnsServers() {
        $servers = [];
        if (isset($this->xml->{'dns-server-list'})) {
            foreach ($this->xml->{'dns-server-list'}->{'dns-entry'} as $dns) {
                $server = (string)$dns;
                if ($server !== '') {
                    $servers[] = $server;
                }
            }
        }
        return $servers;
    }

    /**
     * Parst NTP-Server
     */
    private function parseNtpServers() {
        $servers = [];
        if (isset($this->xml->{'ntp-conf'}->{'ntp-server-list'})) {
            foreach ($this->xml->{'ntp-conf'}->{'ntp-server-list'}->{'ntp-server-ip'} as $ntp) {
                $server = (string)$ntp;
                if ($server !== '') {
                    $servers[] = $server;
                }
            }
        }
        return $servers;
    }

    /**
     * Parst LDAP-Konfiguration
     */
    private function parseLdapConfig() {
        if (!isset($this->xml->ldap)) return [];
        $serverIp = (string)$this->xml->ldap->{'ldap-server-ip'};
        if ($serverIp === '') return [];

        return [
            'use_ldap' => (string)$this->xml->ldap->{'use-ldap'},
            'server_ip' => $serverIp,
            'server_port' => (string)$this->xml->ldap->{'ldap-server-port'}
        ];
    }

    /**
     * Parst SNMP-Konfiguration
     */
    private function parseSnmpConfig() {
        if (!isset($this->xml->{'snmp-conf'})) return [];
        return [
            'version' => (string)$this->xml->{'snmp-conf'}->{'snmp-protocol'}->{'snmp-version'},
            'community' => (string)$this->xml->{'snmp-conf'}->{'snmp-protocol'}->{'snmp-comm-string'}
        ];
    }

    /**
     * Parst Dynamic Routing
     */
    private function parseDynamicRouting() {
        $routing = [];
        if (isset($this->xml->{'dynamic-routing'})) {
            foreach ($this->xml->{'dynamic-routing'}->{'routing-protocol-list'}->{'routing-protocol'} as $protocol) {
                $type = (string)$protocol->{'protocol-type'};
                if ($type !== '') {
                    $routing[$type] = [
                        'enabled' => (string)$protocol->{'protocol-enabled'},
                        'conf_lines' => $this->parseProtocolConf($protocol->{'protocol-conf'})
                    ];
                }
            }
        }
        return $routing;
    }

    /**
     * Parst Protocol-Konfiguration
     */
    private function parseProtocolConf($conf) {
        if (!isset($conf->{'protocol-conf-line'})) return [];
        $lines = [];
        foreach ($conf->{'protocol-conf-line'} as $line) {
            $lineStr = (string)$line;
            if ($lineStr !== '') {
                $lines[] = $lineStr;
            }
        }
        return $lines;
    }

    /**
     * Parst Rollen
     */
    private function parseRoles($roleList) {
        $roles = [];
        if (isset($roleList->role)) {
            foreach ($roleList->role as $role) {
                $roleStr = (string)$role;
                if ($roleStr !== '') {
                    $roles[] = $roleStr;
                }
            }
        }
        return $roles;
    }

    /**
     * Sucht Knoten mit bestimmten Tags
     */
    private function findNodesWithTag($node, $tags, &$results = []) {
        foreach ($tags as $tag) {
            if (isset($node->$tag)) {
                foreach ($node->$tag as $item) {
                    $name = (string)($item['name'] ?? $item['Name'] ?? $item['id'] ?? count($results));
                    if ($name !== '') {
                        $results[$name] = $this->extractNodeData($item);
                    }
                }
            }
        }
        foreach ($node->children() as $child) {
            $this->findNodesWithTag($child, $tags, $results);
        }
        return $results;
    }

    /**
     * Extrahiert Knotendaten
     */
    private function extractNodeData($node) {
        $data = [];
        foreach ($node->attributes() as $key => $value) {
            $strValue = (string)$value;
            if ($strValue !== '') {
                $data[$key] = $strValue;
            }
        }
        foreach ($node->children() as $key => $value) {
            $strValue = (string)$value;
            if ($strValue !== '') {
                $data[$key] = $strValue;
            }
        }
        return $data;
    }

    // ========== GETTER ==========
    public function getType() {
        return $this->type;
    }

    public function getAliases() { return $this->data['aliases'] ?? []; }
    public function getPolicies() { return $this->data['policies'] ?? []; }
    public function getServices() { return $this->data['services'] ?? []; }
    public function getInterfaces() { return $this->data['interfaces'] ?? []; }
    public function getUsers() { return $this->data['users'] ?? []; }
    public function getGroups() { return $this->data['groups'] ?? []; }

    public function getAccounts() { return $this->data['accounts'] ?? []; }
    public function getRoutes() { return $this->data['routes'] ?? []; }
    public function getBlockedIps() { return $this->data['blockedIps'] ?? []; }
    public function getExceptionIps() { return $this->data['exceptionIps'] ?? []; }
    public function getDnsServers() { return $this->data['dnsServers'] ?? []; }
    public function getNtpServers() { return $this->data['ntpServers'] ?? []; }
    public function getLdapConfig() { return $this->data['ldapConfig'] ?? []; }
    public function getSnmpConfig() { return $this->data['snmpConfig'] ?? []; }
    public function getDynamicRouting() { return $this->data['dynamicRouting'] ?? []; }

    public function getStatistics() {
        $stats = [];
        foreach ($this->data as $key => $value) {
            $stats[$key] = is_array($value) ? count($value) : 0;
        }
        return $stats;
    }

    /**
     * Gibt alle geparsten Daten zurück
     */
    public function getAllData() {
        return $this->data;
    }
}