<?php
class AdvancedComparator {
    private $model1;
    private $model2;

    public function __construct(PolicyModel $model1, PolicyModel $model2) {
        $this->model1 = $model1;
        $this->model2 = $model2;
    }

    /**
     * Hauptmethode zum Vergleichen zweier Modelle
     */
    public function compare() {
        // Prüfe, ob beide Dateien vom gleichen Typ sind
        if ($this->model1->getType() !== $this->model2->getType()) {
            throw new Exception("Die beiden Dateien sind von unterschiedlichen Typen. " .
                "Datei 1 ist vom Typ '{$this->model1->getType()}', Datei 2 vom Typ '{$this->model2->getType()}'. " .
                "Bitte vergleichen Sie nur Dateien vom gleichen Typ.");
        }

        $type = $this->model1->getType();

        // Daten abrufen
        $data1 = $this->model1->getAllData();
        $data2 = $this->model2->getAllData();

        // Vergleich durchführen
        return [
            'type' => $type,
            'statistics' => $this->compareStatistics($data1, $data2),
            'differences' => $this->findDifferences($data1, $data2),
            'summary' => $this->getSummary($data1, $data2)
        ];
    }

    /**
     * Vergleicht Statistiken zwischen zwei Datensätzen
     */
    private function compareStatistics($data1, $data2) {
        $diffStats = [];

        // Alle Kategorien aus beiden Datensätzen sammeln
        $allKeys = array_unique(array_merge(array_keys($data1), array_keys($data2)));

        foreach ($allKeys as $key) {
            $value1 = isset($data1[$key]) ? (is_array($data1[$key]) ? count($data1[$key]) : 1) : 0;
            $value2 = isset($data2[$key]) ? (is_array($data2[$key]) ? count($data2[$key]) : 1) : 0;
            $diff = $value2 - $value1;

            $diffStats[$key] = [
                'file1' => $value1,
                'file2' => $value2,
                'difference' => $diff
            ];
        }

        return $diffStats;
    }

    /**
     * Findet Unterschiede zwischen zwei Datensätzen
     */
    private function findDifferences($data1, $data2) {
        $differences = [];

        // Alle Kategorien aus beiden Datensätzen sammeln
        $allKeys = array_unique(array_merge(array_keys($data1), array_keys($data2)));

        foreach ($allKeys as $category) {
            $items1 = $data1[$category] ?? [];
            $items2 = $data2[$category] ?? [];

            $differences[$category] = [
                'label' => $this->getCategoryLabel($category),
                'data' => $this->compareItems($items1, $items2)
            ];
        }

        return $differences;
    }

    /**
     * Vergleicht einzelne Elemente
     */
    private function compareItems($items1, $items2) {
        $onlyIn1 = [];
        $onlyIn2 = [];
        $different = [];
        $identical = [];

        // Konvertiere in Arrays, falls nicht schon
        $items1 = is_array($items1) ? $items1 : [];
        $items2 = is_array($items2) ? $items2 : [];

        foreach ($items1 as $key => $value) {
            if (!array_key_exists($key, $items2)) {
                $onlyIn1[$key] = $value;
            } elseif (serialize($value) !== serialize($items2[$key])) {
                $different[$key] = [
                    'file1' => $value,
                    'file2' => $items2[$key]
                ];
            } else {
                $identical[$key] = $value;
            }
        }

        foreach ($items2 as $key => $value) {
            if (!array_key_exists($key, $items1)) {
                $onlyIn2[$key] = $value;
            }
        }

        return [
            'only_in_file1' => $onlyIn1,
            'only_in_file2' => $onlyIn2,
            'different' => $different,
            'identical' => $identical
        ];
    }

    /**
     * Erstellt eine Zusammenfassung der Unterschiede
     */
    private function getSummary($data1, $data2) {
        $differences = $this->findDifferences($data1, $data2);
        $summary = [
            'total_differences' => 0,
            'categories_with_differences' => []
        ];

        foreach ($differences as $category => $data) {
            $count = count($data['data']['only_in_file1']) +
                     count($data['data']['only_in_file2']) +
                     count($data['data']['different']);
            if ($count > 0) {
                $summary['total_differences'] += $count;
                $summary['categories_with_differences'][] = $category;
            }
        }

        return $summary;
    }

    /**
     * Gibt ein lesbares Label für eine Kategorie zurück
     */
    private function getCategoryLabel($category) {
        $labels = [
            // Policy-Dateien
            'aliases' => 'Aliase',
            'policies' => 'Policies',
            'services' => 'Services',
            'interfaces' => 'Interfaces',
            'users' => 'Benutzer',
            'groups' => 'Gruppen',

            // System-Konfigurationen
            'accounts' => 'Benutzerkonten',
            'routes' => 'Routing-Einträge',
            'blockedIps' => 'Blockierte IPs',
            'exceptionIps' => 'IP-Ausnahmen',
            'dnsServers' => 'DNS-Server',
            'ntpServers' => 'NTP-Server',
            'ldapConfig' => 'LDAP-Konfiguration',
            'snmpConfig' => 'SNMP-Konfiguration',
            'dynamicRouting' => 'Dynamic Routing'
        ];

        return $labels[$category] ?? $category;
    }
}