<?php
class PolicyController {
    private $uploadView;
    private $policyView;
    private $errorView;

    public function __construct() {
        $this->uploadView = new UploadView();
        $this->policyView = new PolicyView();
        $this->errorView = new ErrorView();
    }

    public function handleRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['compare'])) {
            $this->handleFileUpload();
        } else {
            $this->uploadView->render();
        }
    }

    private function handleFileUpload() {
        try {
            $file1 = $this->validateAndSaveFile('file1');
            $file2 = $this->validateAndSaveFile('file2');

            $model1 = new PolicyModel($file1);
            $model1->loadXml();

            $model2 = new PolicyModel($file2);
            $model2->loadXml();

//ur            $comparator = new Comparator($model1, $model2);

            // Neues:
            require_once __DIR__ . '/../models/AdvancedComparator.php';
            $comparator = new AdvancedComparator($model1, $model2, __DIR__ . '/../../comparison_config.php');

            $results = $comparator->compare();

            $this->policyView->render($results, $file1, $file2);

            $this->cleanupTempFiles($file1, $file2);

        } catch (Exception $e) {
            $this->errorView->render($e->getMessage(), $file1 ?? null, $file2 ?? null);
            if (isset($file1) && file_exists($file1)) unlink($file1);
            if (isset($file2) && file_exists($file2)) unlink($file2);
        }
    }

    private function validateAndSaveFile($fieldName) {
        if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Datei wurde nicht hochgeladen oder Fehler beim Upload');
        }

        $file = $_FILES[$fieldName];
        $fileType = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if ($fileType !== 'xml') {
            throw new Exception('Nur XML-Dateien sind erlaubt');
        }

        $tempDir = sys_get_temp_dir();
        $tempFile = tempnam($tempDir, 'wg_');
        if (!move_uploaded_file($file['tmp_name'], $tempFile)) {
            throw new Exception('Fehler beim Speichern der temporären Datei');
        }

        return $tempFile;
    }

    private function cleanupTempFiles($file1, $file2) {
        if (file_exists($file1)) unlink($file1);
        if (file_exists($file2)) unlink($file2);
    }
}