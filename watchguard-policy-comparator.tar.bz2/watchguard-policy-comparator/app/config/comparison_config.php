<?php
/**
 * WatchGuard Comparison Configuration
 * Definiert alle zu vergleichenden Kategorien und deren Struktur
 */

// 1. Strukturdatei-Pfad nur einmal definieren
if (!defined('STRUCTURE_FILE')) {
    define('STRUCTURE_FILE', __DIR__ . '/../../watchguard_structure.json');
}

// 2. Standard-Konfiguration
if (!isset($comparisonConfig)) {
    $comparisonConfig = [
        // POLICY-DATEIEN
        'policy' => [
            'aliases' => ['label' => 'Aliase', 'key' => 'name', 'attributes' => ['name', 'type', 'description']],
            'policies' => ['label' => 'Policies', 'key' => 'name', 'attributes' => ['name', 'from', 'to', 'service', 'action']],
            'services' => ['label' => 'Services', 'key' => 'name', 'attributes' => ['name', 'protocol', 'port']],
            'interfaces' => ['label' => 'Interfaces', 'key' => 'name', 'attributes' => ['name', 'ip', 'type']],
            'users' => ['label' => 'Benutzer', 'key' => 'name', 'attributes' => ['name', 'fullname', 'email']],
            'groups' => ['label' => 'Gruppen', 'key' => 'name', 'attributes' => ['name', 'description']]
        ],
        // SYSTEM-KONFIGURATIONEN
        'system' => [
            'accounts' => ['label' => 'Benutzerkonten', 'key' => 'id', 'attributes' => ['id', 'password', 'description']],
            'routes' => ['label' => 'Routing-Einträge', 'key' => ['dest-address', 'gateway-ip'], 'attributes' => ['dest-address', 'mask', 'gateway-ip']],
            'blockedIps' => ['label' => 'Blockierte IPs', 'key' => ['host-ip-addr', 'ip-type'], 'attributes' => ['ip-type', 'host-ip-addr']],
            'exceptionIps' => ['label' => 'IP-Ausnahmen', 'key' => ['ip-network-addr', 'host-ip-addr', 'ip-type'], 'attributes' => ['ip-type', 'description']],
            'policies' => ['label' => 'Policies', 'key' => 'name', 'attributes' => ['name', 'from', 'to', 'service', 'action']],
            'dnsServers' => ['label' => 'DNS-Server', 'key' => 'index', 'attributes' => []],
            'ntpServers' => ['label' => 'NTP-Server', 'key' => 'index', 'attributes' => []]
        ]
    ];
}

// 3. Funktionen nur definieren, wenn sie nicht existieren
if (!function_exists('extractCategoriesFromStructure')) {
    function extractCategoriesFromStructure($structure, $path = '') {
        $categories = [];
        if (!is_array($structure) || !isset($structure['children'])) {
            return $categories;
        }
        foreach ($structure['children'] as $tag => $child) {
            $currentPath = $path ? "$path.$tag" : $tag;
            if (isset($child['type']) && $child['type'] === 'list') {
                $key = is_array($child['key'] ?? null) ? $child['key'] : ($child['key'] ?? 'index');
                $categories[$currentPath] = [
                    'label' => formatLabel($tag),
                    'key' => $key,
                    'attributes' => is_array($child['item']['attributes'] ?? null) ? $child['item']['attributes'] : []
                ];
            } elseif (isset($child['children']) && is_array($child['children'])) {
                $subCategories = extractCategoriesFromStructure($child, $currentPath);
                $categories = array_merge($categories, $subCategories);
            }
        }
        return $categories;
    }
}

if (!function_exists('formatLabel')) {
    function formatLabel($tag) {
        $replacements = ['-' => ' ', '_' => ' ', 'list' => '', 'entry' => '', 'conf' => ' Konfiguration'];
        return ucfirst(strtolower(trim(str_replace(array_keys($replacements), $replacements, $tag))));
    }
}

if (!function_exists('loadComparisonConfig')) {
    function loadComparisonConfig() {
        global $comparisonConfig;

        // Immer Array zurückgeben
        if (!is_array($comparisonConfig)) {
            $comparisonConfig = [];
        }

        // Strukturdatei laden (falls existiert)
        if (file_exists(STRUCTURE_FILE)) {
            $structureContent = @file_get_contents(STRUCTURE_FILE);
            if ($structureContent !== false) {
                $structure = json_decode($structureContent, true);
                if (is_array($structure)) {
                    $structureCategories = extractCategoriesFromStructure($structure);
                    if (is_array($structureCategories)) {
                        $comparisonConfig = array_merge_recursive($comparisonConfig, $structureCategories);
                    }
                }
            }
        }

        return $comparisonConfig;
    }
}

// 4. Konfiguration zurückgeben (nur einmal)
if (!defined('COMPARISON_CONFIG_LOADED')) {
    define('COMPARISON_CONFIG_LOADED', true);
    return loadComparisonConfig();
}