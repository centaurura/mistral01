# WatchGuard Policy Comparator

PHP MVC Anwendung zum Vergleich von WatchGuard Firebox XML Policy Dateien.

## Installation
1. Alle 4 Teile nacheinander ausführen
2. `watchguard-policy-comparator/public/` als Document Root einrichten
3. Im Browser öffnen: `http://Ihre-Domain/public/`

## Struktur
- **Models**: PolicyModel (XML Parsing), Comparator (Vergleichslogik)
- **Views**: PolicyView, UploadView, ErrorView
- **Controller**: PolicyController
- **Testdaten**: policy1.xml, policy2.xml in test-data/
