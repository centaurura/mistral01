<?php
require_once 'app/config/comparison_config.php';

$config = loadComparisonConfig();

echo "<pre>";
echo "=== KONFIGURATIONSTEST ===\n";
echo "Typ: " . gettype($config) . "\n";
echo "Policy: " . (isset($config['policy']) ? "✅" : "❌") . "\n";
echo "System: " . (isset($config['system']) ? "✅" : "❌") . "\n";
echo "Anzahl Policy-Kategorien: " . count($config['policy'] ?? []) . "\n";
echo "Anzahl System-Kategorien: " . count($config['system'] ?? []) . "\n";
echo "\n=== VOLLSTÄNDIGE KONFIGURATION ===\n";
print_r($config);
echo "</pre>";