<?php
spl_autoload_register(function ($class) {
    $baseDir = __DIR__ . '/../app/';
    $directories = ['', 'models/', 'views/', 'controllers/'];

    foreach ($directories as $dir) {
        $file = $baseDir . $dir . $class . '.php';
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
});

error_reporting(E_ALL);
ini_set('display_errors', 1);

$controller = new PolicyController();
$controller->handleRequest();